define({
  "level": "error",
  "name": "Movilgas",
  "version": "1.0.0",
  "description": "Movilgas",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-12-04T19:10:51.820Z",
    "url": "https://apidocjs.com",
    "version": "0.25.0"
  }
});
